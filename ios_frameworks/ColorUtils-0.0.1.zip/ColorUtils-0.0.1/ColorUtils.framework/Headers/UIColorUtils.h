//
//  UIColorUtils.h
//  ColorUtils
//
//  Created by 油井 大輔 on 2015/03/27.
//  Copyright (c) 2015年 teamdynamiteapp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UIColorUtils : NSObject

-(UIColor*)UIColorFromRGBA:(long)rgbValue alphaValue:(float)alphaValue;
-(UIColor*)UIColorFromRGB:(long)rgbValue;
-(UIColor*)UIColorFromRGBString:(NSString*)rgbStringValue;
-(UIColor*)UIColorFromRGBAString:(NSString*)rgbStringValue alphaValue:(float)alphaValue;

@end
