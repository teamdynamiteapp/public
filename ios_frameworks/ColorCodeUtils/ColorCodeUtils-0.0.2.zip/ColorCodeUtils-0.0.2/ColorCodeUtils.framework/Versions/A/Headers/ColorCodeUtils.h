//
//  ColorCodeUtils.h
//  ColorCodeUtils
//
//  Created by 油井大輔 on 2015/03/29.
//  Copyright (c) 2015年 team_dynamite_app. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ColorCodeUtils : NSObject

-(UIColor*)UIColorFromRGBA:(long)rgbValue alphaValue:(float)alphaValue;
-(UIColor*)UIColorFromRGB:(long)rgbValue;
-(UIColor*)UIColorFromRGBString:(NSString*)rgbStringValue;
-(UIColor*)UIColorFromRGBAString:(NSString*)rgbStringValue alphaValue:(float)alphaValue;

@end
